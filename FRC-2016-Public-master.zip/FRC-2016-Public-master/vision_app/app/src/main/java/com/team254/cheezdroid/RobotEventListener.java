package com.team254.cheezdroid;

public interface RobotEventListener {
    public void shotTaken();
    public void wantsVisionMode();
    public void wantsIntakeMode();
}
