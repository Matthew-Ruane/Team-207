NOTE

The contents of this folder are intended to be moved to the desktop of a Drivers Station.

This Contains:

 * 2 Smart Dashboard Profiles
 * Runner script
 * CMDOW - windows minary for moving around windows
 * BAT FILE for convenience

To run, double click DRIVERS_STATION.bat

If it opens two of the same windows, in one of them go to File > Open, then open the file at C:\Users\Username\SmartDashboard\save.xml
After that, rerun the program

NOTE: You can close all of the smartdashboard windows by killing the command prompt window