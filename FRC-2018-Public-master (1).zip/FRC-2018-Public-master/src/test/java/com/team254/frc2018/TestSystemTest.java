package com.team254.frc2018;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class TestSystemTest {

    @Test
    public void aTest() {
        // assert statements
        assertEquals(0, 0, "0 must be 0");
    }
}
