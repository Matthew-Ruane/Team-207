package com.team254.frc2018;

import com.team254.frc2018.controlboard.IButtonControlBoard;
import com.team254.frc2018.controlboard.IDriveControlBoard;

public interface IControlBoard extends IDriveControlBoard, IButtonControlBoard {
}