package com.team254.lib.geometry;

public interface IRotation2d<S> extends State<S> {
    public Rotation2d getRotation();
}
