package com.team254.lib.geometry;

public interface ITranslation2d<S> extends State<S> {
    public Translation2d getTranslation();
}
