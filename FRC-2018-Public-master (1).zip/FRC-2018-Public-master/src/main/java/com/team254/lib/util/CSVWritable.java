package com.team254.lib.util;

public interface CSVWritable {
    String toCSV();
}
