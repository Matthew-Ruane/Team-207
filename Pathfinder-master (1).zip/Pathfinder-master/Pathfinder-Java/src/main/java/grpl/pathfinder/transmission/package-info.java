/**
 * Motor transmissions.
 *
 * The grpl.pathfinder.transmission package contains implementations of transmissions, which convert
 * control signals to motion (e.g. motors).
 */
package grpl.pathfinder.transmission;