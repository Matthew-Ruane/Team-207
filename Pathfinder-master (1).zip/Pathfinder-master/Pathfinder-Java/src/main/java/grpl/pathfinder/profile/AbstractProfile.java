package grpl.pathfinder.profile;

public abstract class AbstractProfile implements Profile {
}
